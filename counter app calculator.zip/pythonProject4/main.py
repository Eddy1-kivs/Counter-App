from flask import Flask, render_template
from replit import db

app = Flask(__name__)

# if 'number' not in db:
#     db['number'] = 0

db = {'number': 0}

@app.route('/')
def home():
    return render_template('scratch_1.html')

@app.route('/increment')
def increment():
    db['number'] += 1
    return render_template('scratch_1.html', number=db['number'])

@app.route('/decrement')
def decrement():
    db['number'] -= 1
    return render_template('scratch_1.html', number=db['number'])

app.run(host='127.0.0.1', port=8080, debug=True)